package TablefinderSpring.cadastrousuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
